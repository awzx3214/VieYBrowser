(function() {
  const theScrollBar = document.createElement("div");
  theScrollBar.id = "theScrollBar";
  theScrollBar.innerHTML = "▲<br>▼";
  theScrollBar.setAttribute(
    "style",
    "font-size:1.5vw ;width:6vw ;line-height:5vw ;display: block;text-align:center ;background-color:rgba(255,255,255) ;opacity: 0 ;box-shadow:0px 1px 5px rgba(0,0,0,0.2) ;color:#000 ;position:fixed ;top: -14vw;right:-10vw ;z-index:9999999 ;transition: opacity 0.4s ease-in-out,right 0.4s; border-radius:1vw "
  );
  document.body.appendChild(theScrollBar);
  let webHeight = null;
  let lastScrollTop = null;
  function updateScrollBar() {
    const scrollTop = window.scrollY;
    if (scrollTop !== lastScrollTop) {
      const scrollBarTop =
        (scrollTop / webHeight) * (window.innerHeight - theScrollBar.clientHeight);
      if (scrollBarTop < 0) {
        theScrollBar.style.top = "0";
      } else if (scrollBarTop + theScrollBar.clientHeight > window.innerHeight) {
        theScrollBar.style.top = `${window.innerHeight - theScrollBar.clientHeight}px`;
        webHeight = document.documentElement.scrollHeight - window.innerHeight;
      } else {
        theScrollBar.style.top = `${scrollBarTop}px`;
      }
      lastScrollTop = scrollTop;
    }
    window.requestAnimationFrame(updateScrollBar);
  }
  window.addEventListener("touchstart", function() {
    if (document.documentElement.scrollHeight <= window.innerHeight * 2) {
      return;
    }
    webHeight = document.documentElement.scrollHeight - window.innerHeight;
    updateScrollBar();
  });
  let startOffset = null;
  function startScroll(event) {
    event.preventDefault();
    event.stopPropagation();
    startOffset = event.changedTouches[0].clientY - parseInt(theScrollBar.style.top);
  }
  function scrolling(event) {
    event.preventDefault();
    event.stopPropagation();
    const currentY = event.changedTouches[0].clientY;
    const scrollBarTop = currentY - startOffset;
    if (scrollBarTop < 0) {
      theScrollBar.style.top = "0px";
    } else if (scrollBarTop > window.innerHeight - theScrollBar.clientHeight) {
      theScrollBar.style.top = `${window.innerHeight - theScrollBar.clientHeight}px`;
      webHeight = document.documentElement.scrollHeight - window.innerHeight;
    } else {
      theScrollBar.style.top = `${scrollBarTop}px`;
    }
    const scrollTop =
      (scrollBarTop / (window.innerHeight - theScrollBar.clientHeight)) * webHeight;
    window.scrollTo(window.scrollX, scrollTop);
  }
  theScrollBar.addEventListener("touchstart", startScroll, { passive: false });
  theScrollBar.addEventListener("touchmove", scrolling, { passive: false });
  let timer;
  window.addEventListener("scroll", function() {
    clearTimeout(timer);
    theScrollBar.style.right = "2vw";
    theScrollBar.style.opacity = "0.8";
    timer = setTimeout(() => {
      theScrollBar.style.right = "-10vw";
      theScrollBar.style.opacity = "0";
    }, 1000);
  });
  function bounceAnimation() {
    const scrollTop = window.scrollY;
    const scrollBarHeight = theScrollBar.clientHeight;
    const scrollSpeed = Math.abs(scrollTop - lastScrollTop);
    const threshold = 7;
    if (scrollTop === 0 && scrollSpeed > threshold) {
      theScrollBar.style.animation = "bounce-down 0.4s";
      setTimeout(() => {
        theScrollBar.style.animation = "";
      }, 500);
    }
    if (scrollTop + window.innerHeight >= document.documentElement.scrollHeight && scrollSpeed > threshold) {
      theScrollBar.style.animation = "bounce-up 0.4s";
      setTimeout(() => {
        theScrollBar.style.animation = "";
      }, 500);
    }
  }
  window.addEventListener("scroll", bounceAnimation);
  const styles = `
  @keyframes bounce-down {
    0% {
      transform: translateY(0);
    }
    30% {
      transform: translateY(10px);
    }
    100% {
      transform: translateY(0);
    } 
  }
  @keyframes bounce-up {
    0% {
      transform: translateY(0);
    }
     30% {
      transform: translateY(-10px);
    }
    100% {
      transform: translateY(0);
    }
  }
  `;
  const styleElement = document.createElement("style");
  styleElement.innerHTML = styles;
  document.head.appendChild(styleElement);
})();