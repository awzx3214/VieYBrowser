function parseUrl(theurl) {
    theurl = theurl.replace(/%09/g,'%2509').replace(/%2b/g,'%252b').replace(/%2B/g,'%252B');
    
    let protocol = theurl.match(/^[a-zA-Z][\w+.-]*:\/\//)?.[0] || '';
    let prot = protocol.replace('://','');
        host = '',
        port = '',
        name = '',
        pwd = '',
        path = '',
        data = {},
        url = theurl,
        erl = '';
    theurl = theurl.replace(/^[a-zA-Z][\w+.-]*:\/\//, 'http://');
    
    try {
        const u = new URL(theurl);
        host = u.hostname;
        port = u.port || '';
        name = u.username || '';
        pwd = u.password || '';
        path = decodeURI(u.pathname) || '';
        data = Object.fromEntries(u.searchParams) || {};
        if (pwd) {
             let newpwd = '*'.repeat(pwd.length);
             let authPart = name ? `${name}:${newpwd}@` : '';
             let hostPort = port ? `${host}:${port}` : host;
             erl = `${prot}://${authPart}${hostPort}${u.pathname}${u.search}${u.hash}`;
         } else {
             erl = url;
         }
    } catch (e) {
      console.log(e);
    }
    return {
        prot,
        host,
        port,
        name,
        pwd,
        path,
        data,
        url,
        erl
    };
}

function putObjValue(id, v) {
    document.getElementById(id).value = v;
}

function setFont() {
    document.querySelectorAll('*').forEach((element) => {
        element.style.fontFamily = 'system-ui';
    });
}

function getParam(name) {
    return getParam2(name);
}

function getParam2(name) {
    let searchStr = window.location.search;
    searchStr = searchStr.replace(/%09/g,'%2509').replace(/%2b/g,'%252b').replace(/%2B/g,'%252B');
    let urlStart = searchStr.indexOf('url=');
    let r = '';
    if (urlStart !== -1) {
        r = searchStr.substring(urlStart + 4);
    }
    let ou = decodeURIComponent(r);
    let str = '';
    const p = ou.indexOf('://');
    if(p !== -1){
        str = ou.slice(p + 3);
        if(!str.includes('/')){
            ou += '/';
        }
    }
    return ou;
}

function downUrl(pro, name, pwd, url, port, file) {
    if (url.includes("://")) {
        url = url.substring(url.indexOf("://") + 3);
        if (url.includes("/")) {
            url = url.substring(0, url.indexOf("/"));
        }
    }
    if (!pro.includes("://")) {
        pro = pro + "://";
    }
    let q = "";
    if (name != null && name !== "" && pwd != null && pwd !== "") {
        q = `${name}:${pwd}@`;
    } else if (name != null && name !== "") {
        q = `${name}@`;
    }
    if (port != null && port !== "") {
        url = `${url}:${port}`;
    }
    return pro + q + url + file;
}

function getSize(str) {
    if (str == '文件夹') return str;
    const num = parseFloat(str.replace(/[^\d.]/g, ''));
    if (isNaN(num)) return '无法获取大小';
    const units = ['B', 'KB', 'MB', 'GB', 'PB'];
    const base = 1024;
    let index = 0;
    let result = num;
    while (result >= base && index < units.length - 1) {
        result /= base;
        index++;
    }
    return `${result.toFixed(2)} ${units[index]}`;
}

function pwdInput(id, run) {
    const inputEl = document.getElementById(id);
    inputEl.type = 'password';
    inputEl.noPwd = 'yes';
    const style = document.createElement('style');
    style.textContent = '.eye-icon {position: absolute;right: 12px;top: 50%;transform: translateY(-50%);cursor: pointer;width: 20px;height: 20px;fill: rgba(0,0,0,0);transition: fill 0.2s;}';
    document.head.appendChild(style);
    const eyeShowSvg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    eyeShowSvg.setAttribute('class', 'eye-icon');
    eyeShowSvg.setAttribute('width', '20');
    eyeShowSvg.setAttribute('height', '20');
    eyeShowSvg.setAttribute('viewBox', '0 0 48 48');
    eyeShowSvg.innerHTML = '<path d="M24 36C35.0457 36 44 24 44 24C44 24 35.0457 12 24 12C12.9543 12 4 24 4 24C4 24 12.9543 36 24 36Z" fill="none" stroke="#aaaaaa" stroke-width="3" stroke-linejoin="round"/><path d="M24 29C26.7614 29 29 26.7614 29 24C29 21.2386 26.7614 19 24 19C21.2386 19 19 21.2386 19 24C19 26.7614 21.2386 29 24 29Z" fill="none" stroke="#aaaaaa" stroke-width="3" stroke-linejoin="round"/>';
    const eyeHideSvg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    eyeHideSvg.setAttribute('class', 'eye-icon');
    eyeHideSvg.setAttribute('display', 'none');
    eyeHideSvg.setAttribute('width', '20');
    eyeHideSvg.setAttribute('height', '20');
    eyeHideSvg.setAttribute('viewBox', '0 0 48 48');
    eyeHideSvg.innerHTML = '<path d="M9.85786 18C6.23858 21 4 24 4 24C4 24 12.9543 36 24 36C25.3699 36 26.7076 35.8154 28 35.4921M20.0318 12.5C21.3144 12.1816 22.6414 12 24 12C35.0457 12 44 24 44 24C44 24 41.7614 27 38.1421 30" stroke="#aaaaaa" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/><path d="M20.3142 20.6211C19.4981 21.5109 19 22.6972 19 23.9998C19 26.7612 21.2386 28.9998 24 28.9998C25.3627 28.9998 26.5981 28.4546 27.5 27.5705" stroke="#aaaaaa" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/><path d="M42 42L6 6" stroke="#aaaaaa" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>';
    let parentEl = inputEl.parentElement;
    if (!parentEl) {
        parentEl = document.createElement('div');
        inputEl.parentNode.insertBefore(parentEl, inputEl);
        parentEl.appendChild(inputEl);
    }
    parentEl.style.position = 'relative';

    parentEl.appendChild(eyeShowSvg);
    parentEl.appendChild(eyeHideSvg);

    function togglePassword() {
        const isPassword = inputEl.type === 'password';
        inputEl.type = isPassword ? 'text' : 'password';
        eyeShowSvg.style.display = isPassword ? 'none' : 'block';
        eyeHideSvg.style.display = isPassword ? 'block' : 'none';
        if(typeof run == 'function') {
          run(isPassword);
        }
    }
    eyeShowSvg.addEventListener('click', togglePassword);
    eyeHideSvg.addEventListener('click', togglePassword);
    togglePassword();
}



function ansi2html(str) {
    let openSpans = [];
    let result = '';
    const ansiRegex = /\x1b\[([0-9;]*)m/g;
    let lastIndex = 0;
    let match;
    const color16 = ['#000000','#aa0000','#00aa00','#aaaa00','#0000aa','#aa00aa','#00aaaa','#aaaaaa','#7f7f7f','#ff0000','#00ff00','#ffff00','#0000ff','#ff00ff','#00ffff','#ffffff'];
    function formHtml(str) {
        return str
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');
    }
    function get256Color(n) {
        if (n < 16) {
            return color16[n];
        }
        if (n >= 16 && n <= 231) {
            const base = n - 16;
            const r = Math.floor(base / 36);
            const g = Math.floor((base % 36) / 6);
            const b = base % 6;
            const rVal = r === 0 ? 0 : 55 + r * 40;
            const gVal = g === 0 ? 0 : 55 + g * 40;
            const bVal = b === 0 ? 0 : 55 + b * 40;
            return `rgb(${rVal},${gVal},${bVal})`;
        }
        const gray = 8 + (n - 232) * 10;
        return `rgb(${gray},${gray},${gray})`;
    }
    while ((match = ansiRegex.exec(str)) !== null) {
        const text = str.slice(lastIndex, match.index);
        result += formHtml(text);
        const codes = match[1].split(';').map(Number).filter(c => !isNaN(c));
        for (let i = 0; i < codes.length; i++) {
            const code = codes[i];
            if (code === 0) {
                while (openSpans.length > 0) {
                    result += '</span>';
                    openSpans.pop();
                }
                continue;
            }
            if (code === 1) {
                result += `<span style="font-weight:bold">`;
                openSpans.push('bold');
                continue;
            }
            if (code === 3) {
                result += `<span style="font-style:italic">`;
                openSpans.push('italic');
                continue;
            }
            if (code === 4) {
                let style;
                style = 'text-decoration:underline';
                result += `<span style="${style}">`;
                openSpans.push('underline');
                continue;
            }
            if (code === 7) {
                result += `<span style="filter:invert(1)">`;
                openSpans.push('invert');
                continue;
            }
            if (code === 8) {
                result += `<span style="visibility:hidden">`;
                openSpans.push('hide');
                continue;
            }
            if (code === 9) {
                result += `<span style="text-decoration:line-through">`;
                openSpans.push('strike');
                continue;
            }
            if (code >= 30 && code <= 37) {
                const idx = code - 30;
                const color = color16[idx];
                result += `<span style="color:${color}">`;
                openSpans.push('fg');
                continue;
            }
            if (code >= 40 && code <= 47) {
                const idx = code - 40;
                result += `<span style="background-color:${color16[idx]}">`;
                openSpans.push('bg');
                continue;
            }
            if (code === 38 && codes[i + 1] === 5) {
                const n = codes[i + 2];
                const color = get256Color(n);
                result += `<span style="color:${color}">`;
                openSpans.push('fg256');
                i += 2;
                continue;
            }
            if (code === 48 && codes[i + 1] === 5) {
                const n = codes[i + 2];
                const color = get256Color(n);
                result += `<span style="background-color:${color}">`;
                openSpans.push('bg256');
                i += 2;
                continue;
            }
            if (code === 38 && codes[i + 1] === 2) {
                const r = codes[i + 2];
                const g = codes[i + 3];
                const b = codes[i + 4];
                const color = `rgb(${r},${g},${b})`;
                result += `<span style="color:${color}">`;
                openSpans.push('color');
                i += 4;
                continue;
            }
            if (code === 48 && codes[i + 1] === 2) {
                const r = codes[i + 2];
                const g = codes[i + 3];
                const b = codes[i + 4];
                const color = `rgb(${r},${g},${b})`;
                result += `<span style="background-color:${color}">`;
                openSpans.push('bg');
                i += 4;
                continue;
            }
        }
        lastIndex = ansiRegex.lastIndex;
    }
    result += formHtml(str.slice(lastIndex));
    while (openSpans.length > 0) {
        result += '</span>';
        openSpans.pop();
    }
    const underlineSpans = result.match(/<span style="text-decoration:underline">.*?<\/span>/g) || [];
    for (const uSpan of underlineSpans) {
        let colorVal = null;
        const innerColorMatch = uSpan.match(/<span style="color:(#[0-9a-fA-F]+|rgb\([^)]+\))">/);
        if (innerColorMatch) {
            colorVal = innerColorMatch[1];
        }
        if (!colorVal) {
            const outerColorMatch = result.match(/<span style="color:(#[0-9a-fA-F]+|rgb\([^)]+\))">([\s\S]*?)<span style="text-decoration:underline">/);
            if (outerColorMatch) {
                colorVal = outerColorMatch[1];
            }
        }
        if (colorVal) {
            result = result.replace(uSpan, uSpan.replace('text-decoration:underline', `text-decoration:underline;color:${colorVal}`));
        }
    }
    return result;
}